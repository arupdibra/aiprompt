// File: src/api/deepseek.js
import axios from 'axios';

const deepseekAPI = axios.create({
  baseURL: 'https://api.deepseek.com/v1',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${process.env.REACT_APP_DEEPSEEK_API_KEY}`
  }
});

export const generateContent = async (prompt) => {
  try {
    const response = await deepseekAPI.post('/chat/completions', {
      model: "deepseek-chat",
      messages: [{
        role: "user",
        content: prompt
      }],
      temperature: 0.7,
      max_tokens: 1000
    });
    
    return response.data.choices[0].message.content;
  } catch (error) {
    throw new Error(handleAPIError(error));
  }
};

const handleAPIError = (error) => {
  if (error.response) {
    switch (error.response.status) {
      case 401: return 'Invalid API Key';
      case 429: return 'Too many requests';
      case 500: return 'Server error';
      default: return 'API request failed';
    }
  }
  return 'Network error';
};