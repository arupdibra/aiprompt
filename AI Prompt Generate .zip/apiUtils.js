// File: src/utils/apiUtils.js
export const rateLimiter = {
  lastRequest: 0,
  delay: 1000,

  async wait() {
    const now = Date.now();
    const waitTime = this.delay - (now - this.lastRequest);
    if (waitTime > 0) await new Promise(resolve => setTimeout(resolve, waitTime));
    this.lastRequest = Date.now();
  }
};

export const optimizePrompt = (prompt) => {
  return prompt
    .trim()
    .replace(/\s+/g, ' ')
    .substring(0, 1000);
};