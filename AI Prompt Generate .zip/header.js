// File: src/components/Header.js
import React from 'react';

const Header = () => (
  <header className="app-header">
    <h1>AI Prompt Generator</h1>
    <p>Powered by DeepSeek AI</p>
  </header>
);

export default Header;