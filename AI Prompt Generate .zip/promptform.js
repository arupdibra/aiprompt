// File: src/components/PromptForm.js
import React, { useState } from 'react';

const PromptForm = ({ onSubmit, loading, results, error }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(input);
  };

  return (
    <div className="prompt-form">
      <form onSubmit={handleSubmit}>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter your prompt..."
          disabled={loading}
        />
        
        <button type="submit" disabled={loading}>
          {loading ? 'Generating...' : 'Generate'}
        </button>
      </form>

      {error && <div className="error">{error}</div>}

      <div className="results">
        {results.map((result, index) => (
          <div key={index} className="result-item">
            {result}
          </div>
        ))}
      </div>
    </div>
  );
};

export default PromptForm;