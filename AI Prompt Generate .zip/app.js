import React, { useState, useEffect } from 'react';
import { 
  Container,
  CssBaseline,
  Typography,
  TextField,
  Button,
  Paper,
  CircularProgress,
  Snackbar,
  Alert,
  Grid,
  Card,
  CardContent,
  CardActions,
  IconButton
} from '@mui/material';
import { makeStyles } from '@mui/styles';
import { CopyAll, History } from '@mui/icons-material';
import DOMPurify from 'dompurify';

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(4),
    minHeight: '100vh',
    background: 'linear-gradient(45deg, #6366f1 30%, #8b5cf6 90%)',
  },
  header: {
    color: '#ffffff',
    marginBottom: theme.spacing(4),
  },
  promptBox: {
    padding: theme.spacing(4),
    borderRadius: '16px',
    backdropFilter: 'blur(10px)',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  resultCard: {
    marginTop: theme.spacing(2),
    transition: 'transform 0.2s',
    '&:hover': {
      transform: 'translateY(-4px)',
    },
  },
}));

function App() {
  const classes = useStyles();
  const [input, setInput] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const savedHistory = localStorage.getItem('promptHistory');
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  }, []);

  const handleGenerate = async () => {
    if (!input.trim()) {
      setError('Please enter a prompt idea');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.REACT_APP_OPENAI_KEY}`
        },
        body: JSON.stringify({
          model: "gpt-4",
          messages: [{
            role: "system",
            content: "You are a professional prompt engineer. Generate 3 optimized prompts based on the user input."
          }, {
            role: "user",
            content: input
          }],
          temperature: 0.7,
          max_tokens: 150
        })
      });

      if (!response.ok) throw new Error('API request failed');
      
      const data = await response.json();
      const newResults = data.choices[0].message.content.split('\n').filter(r => r);
      
      setResults(newResults);
      saveToHistory(newResults);
    } catch (err) {
      setError('Failed to generate prompts. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const saveToHistory = (newResults) => {
    const newHistory = [{
      input,
      results: newResults,
      timestamp: new Date().toISOString()
    }, ...history.slice(0, 9)];
    
    setHistory(newHistory);
    localStorage.setItem('promptHistory', JSON.stringify(newHistory));
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setError('Copied to clipboard!');
  };

  return (
    <div className={classes.root}>
      <CssBaseline />
      <Container maxWidth="md">
        <Typography variant="h2" className={classes.header} gutterBottom>
          AI Prompt Generator
        </Typography>

        <Paper className={classes.promptBox} elevation={3}>
          <TextField
            fullWidth
            variant="outlined"
            label="Enter your idea"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            multiline
            rows={4}
            margin="normal"
          />

          <Button
            variant="contained"
            color="primary"
            size="large"
            onClick={handleGenerate}
            disabled={loading}
            startIcon={loading ? <CircularProgress size={24} /> : null}
          >
            {loading ? 'Generating...' : 'Generate Prompts'}
          </Button>

          <Grid container spacing={2} style={{ marginTop: '16px' }}>
            {results.map((result, index) => (
              <Grid item xs={12} key={index}>
                <Card className={classes.resultCard}>
                  <CardContent>
                    <div 
                      dangerouslySetInnerHTML={{ 
                        __html: DOMPurify.sanitize(result) 
                      }} 
                    />
                  </CardContent>
                  <CardActions>
                    <IconButton onClick={() => copyToClipboard(result)}>
                      <CopyAll />
                    </IconButton>
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Paper>

        {/* History Sidebar */}
        <Paper className={classes.promptBox} style={{ marginTop: '24px' }}>
          <Typography variant="h6" gutterBottom>
            <History /> Generation History
          </Typography>
          {history.map((entry, index) => (
            <div key={index} style={{ marginBottom: '16px' }}>
              <Typography variant="body2" color="textSecondary">
                {new Date(entry.timestamp).toLocaleString()}
              </Typography>
              <Typography variant="body1">{entry.input}</Typography>
            </div>
          ))}
        </Paper>
      </Container>

      <Snackbar
        open={!!error}
        autoHideDuration={6000}
        onClose={() => setError('')}
      >
        <Alert severity={error.includes('Copied') ? 'success' : 'error'}>
          {error}
        </Alert>
      </Snackbar>
    </div>
  );
}

export default App;